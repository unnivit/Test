export const setSelectedSize = (size) => ({
    type: 'SET_SELECTED_SIZE',
    payload: size,
  });
  

  