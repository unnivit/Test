  const initialState = {
    selectedSize: null,
  };
  
  const rootReducer = (state = initialState, action) => {
    if(action.type==="SET_SELECTED_SIZE")
    {
        return { ...state, selectedSize: action.payload };
    }
    else
    {
        return state;
    }
  };
  
  export default rootReducer;