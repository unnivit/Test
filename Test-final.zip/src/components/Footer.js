import "../styles/Footer.css"

const Footer = () => {
  return (
    <div className='footercontainer'>
        <div className="footercompany">
            <span>Jonathan Simkhai</span>
            <span>Blazers</span>
            <span>Viscose</span>
        </div>
        <h6 className="footerheader">a note from the editor</h6>
        <p className="footercontent">The Forte Lurex Linen Viscose Jacket in Mother of Pearl features lunar lavishness by night and by day: a blazer in a linen blend shot with lurex for a shimmering surface that shines like a star in the sky.</p>
        <p className="footereditor">
           -- By <span>MINNA SHIM</span>, Fashion Editor    
        </p>
    </div>
  )
}

export default Footer