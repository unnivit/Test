import "../styles/Details.css"
const Details = () => {
  return (
    <div className="detailscontainer">
        <ul className="detailsmenu">
            <li className="active">DETAILS</li>
            <li>DELIVERY</li>
            <li>FIT</li>
            <li>SHARE</li>
        </ul>
        <div className="detailstext">
            The Forte Lurex Linen Viscose Jacket in Mother of Pearl features lunar lavishness by night and by day: 
            a blazer in a linen blend shot with lurex for a shimmering surface that shines like a star in the sky. 
            it has a straight fit with well defined shoulders and a shawl collar culminating in a button and has been 
            flawlessly finished with three jet pockets with a sartorial feel.
        </div>
        <div className="detailslink">
            See the <a href="/">EDITOR’S NOTE</a>
        </div>
        <div className="detailslink">
            Learn about the <a href="/">DESIGNER</a>
        </div>
    </div>
  )
}

export default Details