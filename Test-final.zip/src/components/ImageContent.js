import { useState } from "react"
import "../styles/ImageContent.css"
import ladyimg1 from "../images/lady1.png"
import ladyimg2 from "../images/lady4.png"
import ladyimg3 from "../images/lady2.png"
import ladyimg4 from "../images/lady5.png"
import ladyimg5 from "../images/lady3.png"
import wishlist from "../images/wishlist.svg"

const ImageContent = () => { 
  const images = [ladyimg1,ladyimg2,ladyimg3,ladyimg4,ladyimg5];
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const handleIndicatorClick = (index) => {
    setSelectedImageIndex(index);
  };

  return (
    <div className="imagecontainer carousel">
        {images.map((imageUrl, index) => (
        <img loading="lazy" key={index} src={imageUrl} alt={`Model ${index + 1}`} className={`image-preview ${index === selectedImageIndex ? 'active' : ''}`} />
      ))}
       <img className="wishlist" loading="lazy" src={wishlist} alt="wishlist"/>
      <div className="indicators-mobile">
        {images.map((_, index) => (
          <div
            key={index}
            className={`indicator ${index === selectedImageIndex ? 'active' : ''}`}
            onClick={() => handleIndicatorClick(index)}
          ></div>
        ))}
      </div>
    </div>
  )
}

export default ImageContent