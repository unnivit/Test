import { useSelector, useDispatch } from 'react-redux';
import { setSelectedSize } from '../store/actions';
import "../styles/Selection.css"
import ladyimg1 from "../images/ladythumb1.png"
import ladyimg2 from "../images/ladythumb2.png"

const Selection = () => {

  let sizes = [{size:"XS",available:"y"},{size:"S",available:"y"},{size:"M",available:"n"},{size:"L",available:"y"},{size:"XXL",available:"y"}]  
  const selectedSize = useSelector((state) => state.selectedSize);
  const dispatch = useDispatch();

  const handleSizeChange = (size) => {
    dispatch(setSelectedSize(size));
    localStorage.setItem('selectedSize', size);
  };


  return (
    <section className="selectcontainer">
      <div className="selectmaxwidth">
        <h3 className="selecttitle">JONATHAN SIMKHAI</h3>
        <p className="selectdesc">Lurex Linen Viscose Jacket in Conchiglia</p>
        <p className="selectprice">$225</p>
        <p className="selectcolor">COLOR<span>Conchiglia</span></p>
        <div className="selectstyle">
            <img loading="lazy" className="selected" src={ladyimg1} alt="black variant"/>
            <img loading="lazy" src={ladyimg2} alt="gray variant"/>
        </div>
        <div className="selectsizes">
            <span className="sizeselected">Size <span>{selectedSize}</span></span>
            <span className="sizeguide">Size Guide</span>
        </div>
        <div className="selectbag">
            <div className="selectedsize">{sizes.map((val)=>{return<div className={`selectionsizes ${selectedSize === val.size ? 'selection' : ''} ${val.available === "n" ? 'notavailable' : ''}`} onClick={() => handleSizeChange(val.size)}>{val.size}</div>})}</div>
            <button className="addtobag_btn">Add to Bag</button>
            <p className="learnmore">Get 4 interest-free payments of $196.25 with Klarna LEARN MORE</p>
            <p className="chatnow">Speak to a Personal Stylist CHAT NOW</p>
        </div>
      </div>
    </section>
  )
}

export default Selection