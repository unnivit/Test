import { useState } from "react";
import "../styles/Navbar.css";
import searchimg from "../images/search.svg"
import cartimg from "../images/icon-bag.svg"
import accimg from "../images/account.svg"

function Navbar() {

    const [isActive, setIsActive] = useState(false);
    const toggleActiveClass = () => {
      setIsActive(!isActive);
    };
    const removeActive = () => {
      setIsActive(false)
    }
  
  
    return (
      <div className="App">
        <header className="App-header">
  
          <nav className="navbar">
            <a href='/' className="logo">MY COMPANY.COM</a>
            <ul className={`navMenu ${isActive ? `active` : ''}`}>
              <li onClick={removeActive}>
                <a href='/' className="navLink">The Edit</a>
              </li>
              <li onClick={removeActive}>
                <a href='/' className="navLink">New Arrivals</a>
              </li>
              <li onClick={removeActive}>
                <a href='/' className="navLink">Designers</a>
              </li>
              <li onClick={removeActive}>
                <a href='/' className="navLink">Clothing</a>
              </li>
              <li onClick={removeActive}>
                <a href='/' className="navLink">Shoes</a>
              </li>
              <li onClick={removeActive}>
                <a href='/' className="navLink">Bags</a>
              </li>
              <li onClick={removeActive}>
                <a href='/' className="navLink">Accessories</a>
              </li>
              <li onClick={removeActive}>
                <a href='/' className="navLink">Jewelry</a>
              </li>
              <li onClick={removeActive}>
                <a href='/' className="navLink">Beauty</a>
              </li>
              <li onClick={removeActive}>
                <a href='/' className="navLink">home</a>
              </li>
            </ul>
            <ul className="navbaricons">
              <li onClick={removeActive}>
                 <a href='/' className="navLink"><img loading="lazy" src={searchimg} alt="search" /></a>
              </li>
              <li onClick={removeActive}>
                 <a href='/' className="navLink"><img loading="lazy" src={cartimg} alt="cart" /></a>
              </li>
              <li className="mobilehidden" onClick={removeActive}>
                 <a href='/' className="navLink"><img loading="lazy" src={accimg} alt="account" /></a>
              </li>
            </ul>
  
            <div className={`hamburger ${isActive ? `active` : ''}`}  onClick={toggleActiveClass}>
              <span className="bar"></span>
              <span className="bar"></span>
            </div>
          </nav>
  
  
        </header>
      </div>
    );
  }

export default Navbar