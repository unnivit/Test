import './App.css';
import ImageContent from './components/ImageContent';
import Details from './components/Details';
import Navbar from './components/Navbar';
import RightContent from './components/Selection';
import { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { setSelectedSize } from '../src/store/actions';
import Footer from './components/Footer';

function App() {
  const dispatch = useDispatch();

  useEffect(() => {
    const savedSize = localStorage.getItem('selectedSize');
    if (savedSize) {
      dispatch(setSelectedSize(savedSize));
    }
  }, [dispatch]);
  return (
    <div className="App">
      <Navbar />
      <div className='flex'>
        <Details />
        <ImageContent />
        <RightContent />
      </div>
      <Footer />
    </div>
  );
}

export default App;
